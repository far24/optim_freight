./VRPSolver data/100/C203.txt -u 588.8 --cfg config/VRPTW_set_2.cfg  &> out/C203.out
./VRPSolver data/100/C204.txt -u 588.2 --cfg config/VRPTW_set_2.cfg  &> out/C204.out
./VRPSolver data/100/RC204.txt -u 783.6 --cfg config/VRPTW_set_2.cfg  &> out/RC204.out
./VRPSolver data/100/RC207.txt -u 963 --cfg config/VRPTW_set_2.cfg  &> out/RC207.out
./VRPSolver data/100/RC208.txt -u 776.2 --cfg config/VRPTW_set_2.cfg  &> out/RC208.out
./VRPSolver data/100/R202.txt -u 1029.7 --cfg config/VRPTW_set_2.cfg  &> out/R202.out
./VRPSolver data/100/R203.txt -u 870.9 --cfg config/VRPTW_set_2.cfg  &> out/R203.out
./VRPSolver data/100/R204.txt -u 731.4 --cfg config/VRPTW_set_2.cfg  &> out/R204.out
./VRPSolver data/100/R206.txt -u 876 --cfg config/VRPTW_set_2.cfg  &> out/R206.out
./VRPSolver data/100/R207.txt -u 794.1 --cfg config/VRPTW_set_2.cfg  &> out/R207.out
./VRPSolver data/100/R208.txt -u 701.1 --cfg config/VRPTW_set_2.cfg  &> out/R208.out
./VRPSolver data/100/R209.txt -u 854.9 --cfg config/VRPTW_set_2.cfg  &> out/R209.out
./VRPSolver data/100/R210.txt -u 900.6 --cfg config/VRPTW_set_2.cfg  &> out/R210.out
./VRPSolver data/100/R211.txt -u 746.8 --cfg config/VRPTW_set_2.cfg  &> out/R211.out

